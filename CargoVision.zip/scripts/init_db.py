import json
import sqlite3
import random
from datetime import datetime, timedelta
from pathlib import Path

from werkzeug.security import generate_password_hash

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "instance" / "cargovision.sqlite"


DDL = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    senha_hash TEXT NOT NULL,
    perfil TEXT NOT NULL CHECK (perfil IN ('admin','gestor','operador')),
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS veiculos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    placa TEXT NOT NULL UNIQUE,
    tipo TEXT NOT NULL,
    capacidade INTEGER,
    custo_km REAL,
    status TEXT DEFAULT 'disponivel',
    hub TEXT
);

CREATE TABLE IF NOT EXISTS motoristas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cnh TEXT NOT NULL,
    status TEXT DEFAULT 'ativo'
);

CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cnpj_cpf TEXT,
    segmento TEXT
);

CREATE TABLE IF NOT EXISTS enderecos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER,
    tipo TEXT,
    latitude REAL,
    longitude REAL,
    cidade TEXT,
    uf TEXT,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

CREATE TABLE IF NOT EXISTS pedidos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER,
    origem_id INTEGER,
    destino_id INTEGER,
    janela_inicio TEXT,
    janela_fim TEXT,
    sla_minutos INTEGER,
    status TEXT DEFAULT 'pendente',
    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    FOREIGN KEY (origem_id) REFERENCES enderecos(id),
    FOREIGN KEY (destino_id) REFERENCES enderecos(id)
);

CREATE TABLE IF NOT EXISTS viagens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    veiculo_id INTEGER,
    motorista_id INTEGER,
    data_inicio TEXT,
    data_fim TEXT,
    status TEXT,
    hub TEXT,
    FOREIGN KEY (veiculo_id) REFERENCES veiculos(id),
    FOREIGN KEY (motorista_id) REFERENCES motoristas(id)
);

CREATE TABLE IF NOT EXISTS viagem_entrega (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    viagem_id INTEGER,
    pedido_id INTEGER,
    ordem_rota INTEGER,
    status TEXT,
    hora_prevista TEXT,
    hora_real TEXT,
    FOREIGN KEY (viagem_id) REFERENCES viagens(id),
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id)
);

CREATE TABLE IF NOT EXISTS eventos_rastreamento (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    viagem_id INTEGER,
    timestamp TEXT,
    latitude REAL,
    longitude REAL,
    status TEXT,
    observacao TEXT,
    FOREIGN KEY (viagem_id) REFERENCES viagens(id)
);

CREATE TABLE IF NOT EXISTS simulacoes_custo (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    descricao TEXT,
    parametros_json TEXT,
    custo_estimado REAL,
    criado_em TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS previsao_demanda (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    data_referencia TEXT,
    regiao TEXT,
    demanda_prevista REAL
);
"""


def seed_data(conn: sqlite3.Connection):
    cur = conn.cursor()

    # Check if we need to seed (simple check on users table)
    cur.execute("SELECT COUNT(1) FROM usuarios")
    if cur.fetchone()[0] > 0:
        # Check if we have enough vehicles
        cur.execute("SELECT COUNT(1) FROM veiculos")
        count = cur.fetchone()[0]
        if count >= 15:
            print("Database already seeded with enough data.")
            return
        else:
            print("Seeding additional data...")

    # 1. Users
    users = [
        ("Administrador", "admin@cargovision.local", generate_password_hash("admin123"), "admin"),
        ("Gestor Logistico", "gestor@cargovision.local", generate_password_hash("gestor123"), "gestor"),
        ("Operador", "operador@cargovision.local", generate_password_hash("operador123"), "operador"),
    ]
    for u in users:
        try:
            cur.execute("INSERT INTO usuarios (nome, email, senha_hash, perfil) VALUES (?, ?, ?, ?)", u)
        except sqlite3.IntegrityError:
            pass

    # 2. Vehicles (Generate 30 vehicles)
    veiculos = []
    for i in range(1, 31):
        # First 20 are in route, next 3 are delayed, rest are available
        if i <= 20:
            status = "em_rota"
        elif i <= 23:
            status = "atrasado"
        else:
            status = "disponivel"
            
        veiculos.append((f"SP-ROTA{i:02d}", "Vuc" if i % 2 == 0 else "Van", 800 + (i*10), 2.5, status, "CD Paulista"))
    
    for v in veiculos:
        try:
            cur.execute("INSERT INTO veiculos (placa, tipo, capacidade, custo_km, status, hub) VALUES (?, ?, ?, ?, ?, ?)", v)
        except sqlite3.IntegrityError:
            pass

    # 3. Drivers
    motoristas = []
    for i in range(1, 31):
        motoristas.append((f"Motorista {i}", f"CNH{1000+i}", "ativo"))
    
    for m in motoristas:
        cur.execute("INSERT INTO motoristas (nome, cnh, status) VALUES (?, ?, ?)", m)

    # 4. Clients
    clientes = [
        ("Ecommerce Centro", "12.345.678/0001-00", "Ecommerce"),
        ("Mercantil Norte", "98.765.432/0001-99", "Atacado"),
        ("Drogaria Sul", "11.222.333/0001-44", "Varejo"),
        ("Supermercado Leste", "22.333.444/0001-55", "Varejo"),
        ("Tech Solutions", "33.444.555/0001-66", "Eletronicos"),
    ]
    for c in clientes:
        cur.execute("INSERT INTO clientes (nome, cnpj_cpf, segmento) VALUES (?, ?, ?)", c)

    # 5. Addresses (Hub + Random destinations)
    enderecos = [(None, "hub", -23.5505, -46.6333, "Sao Paulo", "SP")]
    # Generate some random points around SP
    base_lat, base_lon = -23.5505, -46.6333
    for i in range(1, 50):
        lat = base_lat + (random.random() - 0.5) * 0.1
        lon = base_lon + (random.random() - 0.5) * 0.1
        enderecos.append((random.randint(1, 5), "destino", lat, lon, "Sao Paulo", "SP"))

    cur.executemany(
        """
        INSERT INTO enderecos (cliente_id, tipo, latitude, longitude, cidade, uf)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        enderecos,
    )

    # 6. Trips (Create trips for the vehicles in route or delayed)
    today = datetime.utcnow().date()
    # Get IDs
    cur.execute("SELECT id, placa, status FROM veiculos WHERE status IN ('em_rota', 'atrasado')")
    veiculos_db = cur.fetchall()
    
    cur.execute("SELECT id FROM motoristas")
    motoristas_db = cur.fetchall()

    viagens = []
    tracking_points = []
    
    for idx, v_row in enumerate(veiculos_db):
        v_id, v_placa, v_status = v_row
        m_id = motoristas_db[idx % len(motoristas_db)][0]
        
        # Create Trip
        cur.execute(
            "INSERT INTO viagens (veiculo_id, motorista_id, data_inicio, data_fim, status, hub) VALUES (?, ?, ?, ?, ?, ?)",
            (v_id, m_id, f"{today}T08:00", None, v_status, "CD Paulista")
        )
        viagem_id = cur.lastrowid
        
        # Create Tracking Event (Current position)
        # Random position around SP
        lat = base_lat + (random.random() - 0.5) * 0.15
        lon = base_lon + (random.random() - 0.5) * 0.15
        
        tracking_points.append((viagem_id, f"{today}T{random.randint(8,16)}:00:00", lat, lon, v_status, f"Em deslocamento - {v_placa}"))

    cur.executemany(
        """
        INSERT INTO eventos_rastreamento (viagem_id, timestamp, latitude, longitude, status, observacao)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        tracking_points,
    )

    # 7. Orders & Deliveries (Populate charts)
    # Get Client IDs
    cur.execute("SELECT id FROM clientes")
    cliente_ids = [r[0] for r in cur.fetchall()]
    
    # Get Address IDs (destinations)
    cur.execute("SELECT id FROM enderecos WHERE tipo='destino'")
    destino_ids = [r[0] for r in cur.fetchall()]
    
    # Get Hub ID
    cur.execute("SELECT id FROM enderecos WHERE tipo='hub' LIMIT 1")
    hub_id = cur.fetchone()[0]

    pedidos = []
    entregas = []
    
    # Generate 150 orders
    for i in range(1, 151):
        c_id = random.choice(cliente_ids)
        dest_id = random.choice(destino_ids)
        sla = random.choice([60, 120, 180, 240])
        
        # Status distribution
        r = random.random()
        if r < 0.6: status = 'concluido'
        elif r < 0.8: status = 'em_rota'
        elif r < 0.9: status = 'pendente'
        else: status = 'atrasado'
        
        pedidos.append((c_id, hub_id, dest_id, f"{today}T08:00", f"{today}T18:00", sla, status))

    cur.executemany(
        """
        INSERT INTO pedidos (cliente_id, origem_id, destino_id, janela_inicio, janela_fim, sla_minutos, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        pedidos,
    )
    
    # Link orders to trips (viagem_entrega)
    # Get all order IDs
    cur.execute("SELECT id, status, sla_minutos FROM pedidos")
    all_pedidos = cur.fetchall()
    
    # Get all trip IDs
    cur.execute("SELECT id FROM viagens")
    all_viagens = [r[0] for r in cur.fetchall()]
    
    for p_row in all_pedidos:
        p_id, p_status, p_sla = p_row
        
        # If order is pending, maybe not assigned to a trip yet, or assigned but not started
        # For 'concluido', 'em_rota', 'atrasado', assign to a trip
        if p_status != 'pendente' and all_viagens:
            v_id = random.choice(all_viagens)
            
            hora_prevista = f"{today}T{random.randint(9, 17):02d}:{random.randint(0, 59):02d}:00"
            hora_real = None
            
            if p_status == 'concluido':
                # Delivered on time or slightly late
                h_prev = datetime.fromisoformat(hora_prevista)
                h_real = h_prev + timedelta(minutes=random.randint(-30, 10))
                hora_real = h_real.isoformat()
            elif p_status == 'atrasado':
                # Predicted time passed, no real time yet or real time is way past
                pass 
            
            entregas.append((v_id, p_id, random.randint(1, 10), p_status, hora_prevista, hora_real))
            
    cur.executemany(
        """
        INSERT INTO viagem_entrega (viagem_id, pedido_id, ordem_rota, status, hora_prevista, hora_real)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        entregas,
    )

    # 7.5 Force 3 SLA Risks (Próximas 2h)
    # We need them to be 'em_rota' and hora_prevista within next 2 hours
    current_utc = datetime.utcnow()
    
    for i in range(3):
        c_id = random.choice(cliente_ids)
        dest_id = random.choice(destino_ids)
        sla = 60
        status = 'em_rota'
        
        # Create Order
        cur.execute(
            "INSERT INTO pedidos (cliente_id, origem_id, destino_id, janela_inicio, janela_fim, sla_minutos, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (c_id, hub_id, dest_id, f"{today}T08:00", f"{today}T23:00", sla, status)
        )
        p_id = cur.lastrowid
        
        # Assign to a random active trip
        if all_viagens:
            v_id = random.choice(all_viagens)
            # Set predicted time to 15-45 mins from now
            target_time = current_utc + timedelta(minutes=15 + i*15)
            hora_prevista = target_time.strftime("%Y-%m-%dT%H:%M:%S")
            
            cur.execute(
                "INSERT INTO viagem_entrega (viagem_id, pedido_id, ordem_rota, status, hora_prevista, hora_real) VALUES (?, ?, ?, ?, ?, ?)",
                (v_id, p_id, 99, status, hora_prevista, None)
            )

    # 8. Simulations & Demand
    demanda_rows = []
    for i in range(7):
        data_ref = today + timedelta(days=i)
        demanda_rows.append((f"{data_ref}", "SP-Centro", 320 + i * 3))
        demanda_rows.append((f"{data_ref}", "SP-Norte", 280 + i * 5))
        demanda_rows.append((f"{data_ref}", "SP-Sul", 260 + i * 4))
    
    cur.executemany(
        """
        INSERT INTO previsao_demanda (data_referencia, regiao, demanda_prevista)
        VALUES (?, ?, ?)
        """,
        demanda_rows,
    )

    conn.commit()
    print("Database seeded with 15+ vehicles in route.")


def main():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(DDL)
    seed_data(conn)
    conn.close()


if __name__ == "__main__":
    main()
