import random
import sqlite3
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "instance" / "cargovision.sqlite"


def next_coordinate(lat, lon):
    return lat + random.uniform(-0.01, 0.01), lon + random.uniform(-0.01, 0.01)


def main():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        SELECT id, hub FROM viagens WHERE status = 'em_rota'
        """
    )
    viagens = cur.fetchall()
    for viagem_id, hub in viagens:
        cur.execute(
            """
            SELECT latitude, longitude FROM eventos_rastreamento
            WHERE viagem_id = ?
            ORDER BY timestamp DESC LIMIT 1
            """,
            (viagem_id,),
        )
        row = cur.fetchone()
        if row:
            lat, lon = row
        else:
            cur.execute("SELECT latitude, longitude FROM enderecos WHERE tipo = 'hub' LIMIT 1")
            lat, lon = cur.fetchone() or (-23.55, -46.63)
        new_lat, new_lon = next_coordinate(lat, lon)
        cur.execute(
            """
            INSERT INTO eventos_rastreamento (viagem_id, timestamp, latitude, longitude, status, observacao)
            VALUES (?, ?, ?, ?, 'em_rota', 'Atualizacao mock')
            """,
            (viagem_id, datetime.utcnow().isoformat(), new_lat, new_lon),
        )
        print(f"Viagem {viagem_id}: {new_lat}, {new_lon}")
    conn.commit()
    conn.close()


if __name__ == "__main__":
    main()
