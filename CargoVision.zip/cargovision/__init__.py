import os
from flask import Flask, redirect, url_for

from .services import db
from .blueprints.auth.routes import bp as auth_bp
from .blueprints.cadastros.routes import bp as cadastros_bp
from .blueprints.monitoramento.routes import bp as monitoramento_bp
from .blueprints.simulacoes.routes import bp as simulacoes_bp


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        SECRET_KEY="dev",
        DATABASE=os.path.join(app.instance_path, "cargovision.sqlite"),
    )

    if test_config is not None:
        app.config.update(test_config)

    os.makedirs(app.instance_path, exist_ok=True)

    db.init_app(app)
    db.init_db(app)

    app.register_blueprint(auth_bp)
    app.register_blueprint(cadastros_bp)
    app.register_blueprint(monitoramento_bp)
    app.register_blueprint(simulacoes_bp)

    @app.route("/")
    def index():
        return redirect(url_for("monitoramento.dashboard"))

    return app
