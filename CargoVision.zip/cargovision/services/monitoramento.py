from datetime import datetime

from . import db


def veiculos_em_rota():
    return db.fetch_all(
        """
        WITH ultimo_evento AS (
            SELECT viagem_id, latitude, longitude, status, MAX(timestamp) AS ts
            FROM eventos_rastreamento
            GROUP BY viagem_id
        )
        SELECT v.id, v.placa, v.tipo, v.status AS status_veiculo, v.hub,
               m.nome AS motorista,
               e.latitude, e.longitude, e.status AS status_evento
        FROM viagens vi
        JOIN veiculos v ON v.id = vi.veiculo_id
        LEFT JOIN motoristas m ON m.id = vi.motorista_id
        LEFT JOIN ultimo_evento e ON e.viagem_id = vi.id
        WHERE vi.status IN ('em_rota','planejada')
        """
    )


def entregas_status():
    return db.fetch_all(
        """
        SELECT ve.id, ve.viagem_id, ve.status, ve.hora_prevista, ve.hora_real,
               c.nome AS cliente,
               ed.latitude, ed.longitude, ed.cidade
        FROM viagem_entrega ve
        JOIN pedidos p ON p.id = ve.pedido_id
        JOIN clientes c ON c.id = p.cliente_id
        JOIN enderecos ed ON ed.id = p.destino_id
        """
    )


def riscos_heatmap():
    agora = datetime.utcnow()
    horizonte_min = 120

    rows = db.fetch_all(
        """
        SELECT ve.id AS entrega_id, ve.status, ve.hora_prevista,
               p.id AS pedido_id,
               c.nome AS cliente,
               ed.latitude, ed.longitude, ed.cidade, ed.uf
        FROM viagem_entrega ve
        JOIN pedidos p ON p.id = ve.pedido_id
        JOIN clientes c ON c.id = p.cliente_id
        JOIN enderecos ed ON ed.id = p.destino_id
        WHERE ve.status IN ('em_rota','pendente','atrasado')
          AND ve.hora_prevista IS NOT NULL
          AND ed.latitude IS NOT NULL
          AND ed.longitude IS NOT NULL
        """
    )

    pontos = []
    for row in rows:
        try:
            hora_prevista = datetime.fromisoformat(row["hora_prevista"])
        except (TypeError, ValueError):
            continue

        minutos_ate_eta = (hora_prevista - agora).total_seconds() / 60

        # Mantém só os pontos que estão atrasados ou dentro das próximas 2h
        if minutos_ate_eta > horizonte_min and row["status"] != "atrasado":
            continue

        urgencia = max(0, horizonte_min - max(minutos_ate_eta, 0))
        peso = 0.35 + (urgencia / horizonte_min) * 0.55

        if row["status"] == "atrasado":
            peso = 1.0
        elif minutos_ate_eta <= 0:
            peso = max(peso, 0.9)

        pontos.append(
            {
                "entrega_id": row["entrega_id"],
                "pedido_id": row["pedido_id"],
                "cliente": row["cliente"],
                "cidade": row["cidade"],
                "status": row["status"],
                "hora_prevista": row["hora_prevista"],
                "latitude": row["latitude"],
                "longitude": row["longitude"],
                "peso": round(min(max(peso, 0.35), 1.0), 2),
            }
        )

    return pontos
