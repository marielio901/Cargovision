import sqlite3
from pathlib import Path
from flask import current_app, g


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


def close_db(_=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_app(app):
    app.teardown_appcontext(close_db)


def init_db(app):
    db_path = Path(app.config["DATABASE"])
    if not db_path.exists():
        db_path.touch()
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.close()


def run_query(query, params=None, commit=False):
    db = get_db()
    cursor = db.execute(query, params or [])
    if commit:
        db.commit()
    return cursor


def fetch_all(query, params=None):
    return run_query(query, params).fetchall()


def fetch_one(query, params=None):
    return run_query(query, params).fetchone()
