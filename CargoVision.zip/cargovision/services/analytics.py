from datetime import datetime

from . import db
from . import monitoramento as monitor_service


def kpi_resumo():
    total = db.fetch_one("SELECT COUNT(1) AS c FROM pedidos")["c"]
    concluidos = db.fetch_one(
        "SELECT COUNT(1) AS c FROM viagem_entrega WHERE status IN ('entregue','concluido')"
    )["c"]
    atrasos = db.fetch_one(
        """
        SELECT COUNT(1) AS c
        FROM viagem_entrega
        WHERE status = 'atrasado'
           OR (hora_real IS NOT NULL AND hora_prevista IS NOT NULL AND hora_real > hora_prevista)
        """
    )["c"]
    dentro_sla = max(concluidos - atrasos, 0)
    percent_sla = (dentro_sla / concluidos * 100) if concluidos else 0
    pendentes = db.fetch_one("SELECT COUNT(1) AS c FROM pedidos WHERE status = 'pendente'")["c"]
    em_rota = db.fetch_one("SELECT COUNT(1) AS c FROM viagem_entrega WHERE status = 'em_rota'")["c"]
    sla_medio = db.fetch_one("SELECT AVG(sla_minutos) AS avg_sla FROM pedidos")["avg_sla"] or 0

    return {
        "total_pedidos": total,
        "entregas_concluidas": concluidos,
        "percentual_sla": round(percent_sla, 1),
        "atrasos": atrasos,
        "pendentes": pendentes,
        "em_rota": em_rota,
        "sla_medio": round(sla_medio, 1),
    }


def ml_insights(riscos_count=None):
    rows = db.fetch_all(
        """
        SELECT data_referencia, AVG(demanda_prevista) AS media
        FROM previsao_demanda
        GROUP BY data_referencia
        ORDER BY data_referencia
        """
    )
    drift = 0
    if len(rows) >= 2 and rows[0]["media"]:
        first = rows[0]["media"]
        last = rows[-1]["media"]
        if first:
            drift = round(((last - first) / first) * 100, 1)

    atrasos = db.fetch_one(
        """
        SELECT COUNT(1) AS c
        FROM viagem_entrega
        WHERE status = 'atrasado'
           OR (hora_real IS NOT NULL AND hora_prevista IS NOT NULL AND hora_real > hora_prevista)
        """
    )["c"]
    total_entregas = db.fetch_one("SELECT COUNT(1) AS c FROM viagem_entrega")["c"] or 0
    confianca_eta = 98.0
    if total_entregas:
        confianca_eta = max(100 - (atrasos / total_entregas * 120), 35)
    confianca_eta = round(min(confianca_eta, 100), 1)

    em_rota = db.fetch_one("SELECT COUNT(1) AS c FROM viagem_entrega WHERE status = 'em_rota'")["c"]

    last_event = db.fetch_one(
        "SELECT timestamp FROM eventos_rastreamento ORDER BY timestamp DESC LIMIT 1"
    )
    latencia_min = None
    if last_event and last_event["timestamp"]:
        try:
            ts = datetime.fromisoformat(last_event["timestamp"])
            delta = datetime.utcnow() - ts
            latencia_min = max(int(delta.total_seconds() // 60), 0)
        except ValueError:
            latencia_min = None

    alertas_abertos = riscos_count if riscos_count is not None else len(entregas_em_risco())

    return {
        "confianca_eta": confianca_eta,
        "drift_demanda": drift,
        "latencia_telemetria_min": latencia_min,
        "inferencias_ativas": em_rota,
        "alertas_abertos": alertas_abertos,
    }


def frota_utilizacao():
    rows = db.fetch_all(
        """
        SELECT hub, status, COUNT(1) AS total
        FROM veiculos
        GROUP BY hub, status
        """
    )
    return [dict(r) for r in rows]


def proximas_entregas(limit=5):
    rows = db.fetch_all(
        """
        SELECT ve.id, p.id AS pedido_id, c.nome AS cliente, ve.status,
               ve.hora_prevista,
               ed.cidade AS destino, ed.latitude, ed.longitude
        FROM viagem_entrega ve
        JOIN pedidos p ON p.id = ve.pedido_id
        JOIN clientes c ON c.id = p.cliente_id
        JOIN enderecos ed ON ed.id = p.destino_id
        ORDER BY ve.hora_prevista ASC
        LIMIT ?
        """,
        (limit,),
    )
    return [dict(r) for r in rows]


def demanda_agrupada():
    rows = db.fetch_all(
        """
        SELECT regiao, data_referencia, demanda_prevista
        FROM previsao_demanda
        ORDER BY data_referencia
        """
    )
    grouped = {}
    for row in rows:
        grouped.setdefault(row["regiao"], []).append(
            {"data": row["data_referencia"], "valor": row["demanda_prevista"]}
        )
    return grouped


def entregas_em_risco():
    riscos = monitor_service.riscos_heatmap()
    return [
        {
            "id": r["entrega_id"],
            "pedido_id": r["pedido_id"],
            "cliente": r["cliente"],
            "destino": r["cidade"],
            "hora_prevista": r["hora_prevista"],
        }
        for r in riscos
    ]


def entregas_por_status():
    rows = db.fetch_all(
        """
        SELECT status, COUNT(1) AS total
        FROM viagem_entrega
        GROUP BY status
        """
    )
    return [dict(r) for r in rows]


def pedidos_por_cliente(limit=6):
    rows = db.fetch_all(
        """
        SELECT c.nome AS cliente, COUNT(1) AS total
        FROM pedidos p
        JOIN clientes c ON c.id = p.cliente_id
        GROUP BY c.id, c.nome
        ORDER BY total DESC
        LIMIT ?
        """,
        (limit,),
    )
    return [dict(r) for r in rows]


def viagens_por_hub_status():
    rows = db.fetch_all(
        """
        SELECT hub, status, COUNT(1) AS total
        FROM viagens
        GROUP BY hub, status
        """
    )
    return [dict(r) for r in rows]


def ultimos_eventos(limit=8):
    rows = db.fetch_all(
        """
        SELECT e.timestamp, e.status, e.observacao, e.latitude, e.longitude,
               v.placa, vi.id AS viagem_id
        FROM eventos_rastreamento e
        JOIN viagens vi ON vi.id = e.viagem_id
        JOIN veiculos v ON v.id = vi.veiculo_id
        ORDER BY e.timestamp DESC
        LIMIT ?
        """,
        (limit,),
    )
    return [dict(r) for r in rows]
