from datetime import datetime

from . import db


def list_clientes():
    return db.fetch_all("SELECT * FROM clientes ORDER BY nome")


def list_veiculos():
    return db.fetch_all("SELECT * FROM veiculos ORDER BY id DESC")


def list_motoristas():
    return db.fetch_all("SELECT * FROM motoristas ORDER BY nome")


def get_hub_endereco_id():
    row = db.fetch_one("SELECT id FROM enderecos WHERE tipo = 'hub' LIMIT 1")
    return row["id"] if row else None


def create_endereco(cliente_id, tipo, latitude, longitude, cidade, uf):
    db.run_query(
        """
        INSERT INTO enderecos (cliente_id, tipo, latitude, longitude, cidade, uf)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (cliente_id, tipo, latitude, longitude, cidade, uf),
        commit=True,
    )
    row = db.fetch_one("SELECT last_insert_rowid() AS id")
    return row["id"]


def create_pedido(cliente_id, destino_lat, destino_lon, cidade, uf, janela_inicio, janela_fim, sla_minutos):
    origem_id = get_hub_endereco_id()
    destino_id = create_endereco(cliente_id, "destino", destino_lat, destino_lon, cidade, uf)
    db.run_query(
        """
        INSERT INTO pedidos (cliente_id, origem_id, destino_id, janela_inicio, janela_fim, sla_minutos, status)
        VALUES (?, ?, ?, ?, ?, ?, 'pendente')
        """,
        (cliente_id, origem_id, destino_id, janela_inicio, janela_fim, sla_minutos),
        commit=True,
    )
    return db.fetch_one("SELECT last_insert_rowid() AS id")["id"]


def list_pedidos():
    return db.fetch_all(
        """
        SELECT p.id, p.janela_inicio, p.janela_fim, p.sla_minutos, p.status,
               c.nome AS cliente_nome,
               ed.latitude AS dest_latitude, ed.longitude AS dest_longitude, ed.cidade AS dest_cidade
        FROM pedidos p
        JOIN clientes c ON c.id = p.cliente_id
        JOIN enderecos ed ON ed.id = p.destino_id
        ORDER BY p.id DESC
        """
    )


def attach_pedido_to_viagem(pedido_id, viagem_id):
    now_iso = datetime.utcnow().isoformat()
    db.run_query(
        """
        INSERT INTO viagem_entrega (viagem_id, pedido_id, ordem_rota, status, hora_prevista, hora_real)
        VALUES (?, ?, (SELECT COALESCE(MAX(ordem_rota),0)+1 FROM viagem_entrega WHERE viagem_id = ?), 'planejado', ?, NULL)
        """,
        (viagem_id, pedido_id, viagem_id, now_iso),
        commit=True,
    )
