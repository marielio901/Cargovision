from werkzeug.security import check_password_hash, generate_password_hash

from . import db


def get_user_by_email(email):
    return db.fetch_one("SELECT * FROM usuarios WHERE email = ?", (email,))


def create_user(nome, email, senha, perfil):
    hashed = generate_password_hash(senha)
    db.run_query(
        """
        INSERT INTO usuarios (nome, email, senha_hash, perfil)
        VALUES (?, ?, ?, ?)
        """,
        (nome, email, hashed, perfil),
        commit=True,
    )


def verify_user(email, senha):
    user = get_user_by_email(email)
    if not user:
        return None
    if not check_password_hash(user["senha_hash"], senha):
        return None
    return user
