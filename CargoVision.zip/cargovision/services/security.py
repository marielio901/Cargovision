from functools import wraps
from flask import g, redirect, url_for, flash


def login_required(view):
    @wraps(view)
    def wrapped(**kwargs):
        if g.get("user") is None:
            flash("Faça login para continuar.", "warning")
            return redirect(url_for("auth.login"))
        return view(**kwargs)

    return wrapped


def role_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(**kwargs):
            user = g.get("user")
            if user is None or user["perfil"] not in roles:
                flash("Permissão insuficiente.", "danger")
                return redirect(url_for("monitoramento.dashboard"))
            return view(**kwargs)

        return wrapped

    return decorator
