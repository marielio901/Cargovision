const map = L.map('map').setView([-23.55, -46.63], 11);

// Use a cleaner, more modern tile layer (CartoDB Positron)
L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
    subdomains: 'abcd',
    maxZoom: 19
}).addTo(map);

let trafficLayer = null;
let heatLayer = null;
let refreshInProgress = false;

const trafficToggle = document.getElementById('trafficLayer');
const heatmapToggle = document.getElementById('heatmapLayer');

const vehicleMarkers = {};
const entregaMarkers = {};
let rotaLayer = null;

function syncTrafficLayer() {
    if (trafficToggle && trafficToggle.checked) {
        if (!trafficLayer) {
            trafficLayer = L.tileLayer('https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors | Camada HOT',
                maxZoom: 19,
                opacity: 0.55
            }).addTo(map);
        }
    } else if (trafficLayer) {
        trafficLayer.remove();
        trafficLayer = null;
    }
}

if (trafficToggle) {
    syncTrafficLayer();
    trafficToggle.addEventListener('change', syncTrafficLayer);
}

function getStatusColor(status) {
    if (status === 'em_rota') return '#10b981'; // success
    if (status === 'atrasado') return '#f59e0b'; // warning
    if (status === 'pendente') return '#64748b'; // secondary
    return '#3b82f6'; // info/default
}

function createCustomIcon(type, status) {
    const color = getStatusColor(status);
    const iconClass = type === 'veiculo' ? 'fa-truck' : 'fa-box';

    return L.divIcon({
        className: 'custom-map-marker',
        html: `<div style="
            background-color: ${color};
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
            border: 2px solid white;
        ">
            <i class="fas ${iconClass}" style="font-size: 14px;"></i>
        </div>`,
        iconSize: [36, 36],
        iconAnchor: [18, 18],
        popupAnchor: [0, -18]
    });
}

function renderVehicles(data) {
    data.forEach(v => {
        const key = `v-${v.id}`;
        const coords = [v.latitude || -23.55, v.longitude || -46.63];

        if (vehicleMarkers[key]) {
            vehicleMarkers[key].setLatLng(coords);
            // Update icon if status changed (optional optimization: check status first)
            vehicleMarkers[key].setIcon(createCustomIcon('veiculo', v.status_evento || v.status_veiculo));
        } else {
            const marker = L.marker(coords, {
                icon: createCustomIcon('veiculo', v.status_evento || v.status_veiculo)
            });

            const popupContent = `
                <div class="p-2">
                    <h6 class="fw-bold mb-1">${v.placa}</h6>
                    <span class="badge bg-light text-dark border mb-2">${v.tipo}</span>
                    <div class="text-muted small"><i class="fas fa-user me-1"></i>${v.motorista || 'Sem motorista'}</div>
                </div>
            `;

            marker.bindPopup(popupContent, { minWidth: 200 });
            marker.addTo(map);
            vehicleMarkers[key] = marker;
        }
    });
}

function renderEntregas(data) {
    data.forEach(e => {
        const key = `e-${e.id}`;
        const coords = [e.latitude, e.longitude];

        if (entregaMarkers[key]) {
            entregaMarkers[key].setLatLng(coords);
        } else {
            const marker = L.marker(coords, {
                icon: createCustomIcon('entrega', e.status)
            });

            const popupContent = `
                <div class="p-2">
                    <h6 class="fw-bold mb-1">Pedido #${e.id}</h6>
                    <div class="fw-semibold text-primary mb-1">${e.cliente}</div>
                    <div class="text-muted small mb-2">${e.cidade}</div>
                    <span class="badge bg-light text-dark border">${e.status}</span>
                </div>
            `;

            marker.bindPopup(popupContent, { minWidth: 200 });
            marker.addTo(map);
            entregaMarkers[key] = marker;
        }
    });
}

async function loadVeiculos() {
    try {
        const res = await fetch('/api/monitoramento/veiculos');
        const data = await res.json();
        renderVehicles(data);
    } catch (err) {
        console.error("Erro ao carregar veículos:", err);
    }
}

async function loadEntregas() {
    try {
        const res = await fetch('/api/monitoramento/entregas');
        const data = await res.json();
        renderEntregas(data);
    } catch (err) {
        console.error("Erro ao carregar entregas:", err);
    }
}

async function loadHeatmap() {
    if (!heatmapToggle || !heatmapToggle.checked) {
        if (heatLayer) {
            heatLayer.remove();
            heatLayer = null;
        }
        return;
    }

    try {
        const res = await fetch('/api/monitoramento/riscos');
        const data = await res.json();

        const pontos = (data || [])
            .filter(p => typeof p.latitude === 'number' && typeof p.longitude === 'number')
            .map(p => [p.latitude, p.longitude, p.peso || 0.4]);

        if (!pontos.length) {
            if (heatLayer) {
                heatLayer.setLatLngs([]);
            }
            return;
        }

        if (heatLayer) {
            heatLayer.setLatLngs(pontos);
        } else {
            heatLayer = L.heatLayer(pontos, {
                radius: 28,
                blur: 20,
                minOpacity: 0.25,
                maxZoom: 17,
                gradient: {
                    0.3: '#22c55e',
                    0.6: '#f59e0b',
                    0.85: '#ef4444'
                }
            }).addTo(map);
        }
    } catch (err) {
        console.error("Erro ao carregar mapa de calor:", err);
    }
}

async function loadRota(viagemId) {
    try {
        const res = await fetch(`/api/monitoramento/rota/${viagemId}`);
        const data = await res.json();

        if (!data.rota || data.rota.length === 0) {
            alert('Nenhuma rota encontrada para esta viagem.');
            return;
        }

        const pontos = [data.hub, ...data.rota.map(r => [r.latitude, r.longitude])];

        if (rotaLayer) rotaLayer.remove();

        rotaLayer = L.polyline(pontos, {
            color: '#2563eb', // Primary blue
            weight: 5,
            opacity: 0.8,
            dashArray: '10, 10', // Dashed line for effect
            lineCap: 'round'
        }).addTo(map);

        map.fitBounds(rotaLayer.getBounds(), { padding: [50, 50] });
    } catch (err) {
        console.error("Erro ao carregar rota:", err);
    }
}

if (heatmapToggle) {
    heatmapToggle.addEventListener('change', () => loadHeatmap());
}

async function refresh() {
    if (refreshInProgress) return;

    refreshInProgress = true;
    try {
        await Promise.all([loadVeiculos(), loadEntregas(), loadHeatmap()]);
    } finally {
        refreshInProgress = false;
    }
}

// Initial load
refresh();

// Auto-refresh every 15s
setInterval(refresh, 15000);
