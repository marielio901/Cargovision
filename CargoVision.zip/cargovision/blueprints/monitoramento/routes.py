from flask import Blueprint, jsonify, render_template

from ...services import analytics
from ...services import db
from ...services import monitoramento as monitor_service
from ...services import route_optimizer
from ...services.security import login_required

bp = Blueprint("monitoramento", __name__)


@bp.route("/dashboard")
@login_required
def dashboard():
    kpis = analytics.kpi_resumo()
    frota = analytics.frota_utilizacao()
    proximas = analytics.proximas_entregas()
    demandas = analytics.demanda_agrupada()
    riscos = analytics.entregas_em_risco()
    ml_insights = analytics.ml_insights(len(riscos))
    entregas_status = analytics.entregas_por_status()
    pedidos_cliente = analytics.pedidos_por_cliente()
    viagens_hub = analytics.viagens_por_hub_status()
    eventos = analytics.ultimos_eventos()
    return render_template(
        "dashboard.html",
        kpis=kpis,
        frota=frota,
        proximas=proximas,
        demandas=demandas,
        riscos=riscos,
        ml_insights=ml_insights,
        entregas_status=entregas_status,
        pedidos_cliente=pedidos_cliente,
        viagens_hub=viagens_hub,
        eventos=eventos,
    )


@bp.route("/monitoramento")
@login_required
def mapa():
    viagens = db.fetch_all("SELECT id, status, hub FROM viagens ORDER BY id DESC")
    return render_template("mapa.html", viagens=viagens)


@bp.route("/api/monitoramento/veiculos")
@login_required
def api_veiculos():
    rows = monitor_service.veiculos_em_rota()
    data = [dict(r) for r in rows]
    return jsonify(data)


@bp.route("/api/monitoramento/entregas")
@login_required
def api_entregas():
    rows = monitor_service.entregas_status()
    data = [dict(r) for r in rows]
    return jsonify(data)


@bp.route("/api/monitoramento/riscos")
@login_required
def api_riscos():
    pontos = monitor_service.riscos_heatmap()
    return jsonify(pontos)


@bp.route("/api/monitoramento/rota/<int:viagem_id>")
@login_required
def api_rota(viagem_id):
    hub_row = db.fetch_one("SELECT latitude, longitude FROM enderecos WHERE tipo = 'hub' LIMIT 1")
    entregas = db.fetch_all(
        """
        SELECT ed.latitude, ed.longitude, ve.ordem_rota, ve.status
        FROM viagem_entrega ve
        JOIN pedidos p ON p.id = ve.pedido_id
        JOIN enderecos ed ON ed.id = p.destino_id
        WHERE ve.viagem_id = ?
        """,
        (viagem_id,),
    )
    if not hub_row or not entregas:
        return jsonify({"rota": []})
    hub = (hub_row["latitude"], hub_row["longitude"])
    ordenada = route_optimizer.nearest_neighbor_route(
        hub, [dict(e) for e in entregas]
    )
    return jsonify({"hub": hub, "rota": ordenada})
