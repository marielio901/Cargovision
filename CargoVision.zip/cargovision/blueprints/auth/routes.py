from flask import Blueprint, render_template, request, redirect, url_for, session, flash, g

from ...services import auth as auth_service
from ...services import db

bp = Blueprint("auth", __name__, url_prefix="/auth")


@bp.before_app_request
def load_logged_in_user():
    user_id = session.get("user_id")
    g.user = None
    if user_id is not None:
        g.user = db.fetch_one("SELECT id, nome, email, perfil FROM usuarios WHERE id = ?", (user_id,))


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        senha = request.form.get("senha")
        user = auth_service.verify_user(email, senha)
        if user:
            session.clear()
            session["user_id"] = user["id"]
            flash("Login efetuado.", "success")
            return redirect(url_for("monitoramento.dashboard"))
        flash("Credenciais inválidas.", "danger")
    return render_template("login.html")


@bp.route("/logout")
def logout():
    session.clear()
    flash("Sessão encerrada.", "info")
    return redirect(url_for("auth.login"))
