import json
from datetime import datetime

from flask import Blueprint, flash, redirect, render_template, request, url_for

from ...services import db
from ...services.security import login_required, role_required

bp = Blueprint("simulacoes", __name__, url_prefix="/simulacoes")


@bp.route("", methods=["GET"])
@login_required
def index():
    simulacoes = [dict(r) for r in db.fetch_all(
        "SELECT id, descricao, parametros_json, custo_estimado, criado_em FROM simulacoes_custo ORDER BY id DESC"
    )]
    demanda = [dict(r) for r in db.fetch_all(
        "SELECT regiao, data_referencia, demanda_prevista FROM previsao_demanda ORDER BY data_referencia"
    )]
    return render_template("simulacoes.html", simulacoes=simulacoes, demanda=demanda)


@bp.route("/rodar", methods=["POST"])
@login_required
@role_required("gestor", "admin")
def rodar():
    try:
        combustivel = float(request.form.get("combustivel"))
        pedagios = float(request.form.get("pedagios"))
        distancia_media = float(request.form.get("distancia_media"))
        entregas = int(request.form.get("entregas"))
        custo_km = float(request.form.get("custo_km"))
        descricao = request.form.get("descricao") or "Simulacao rapida"
    except (TypeError, ValueError):
        flash("Preencha os números corretamente.", "danger")
        return redirect(url_for("simulacoes.index"))

    km_total = distancia_media * max(entregas, 1)
    custo_combustivel = km_total * (combustivel / 6.5)
    custo_operacional = km_total * custo_km
    custo_total = round(custo_combustivel + custo_operacional + pedagios, 2)

    params = {
        "combustivel": combustivel,
        "pedagios": pedagios,
        "distancia_media": distancia_media,
        "entregas": entregas,
        "custo_km": custo_km,
    }
    db.run_query(
        """
        INSERT INTO simulacoes_custo (descricao, parametros_json, custo_estimado, criado_em)
        VALUES (?, ?, ?, ?)
        """,
        (descricao, json.dumps(params), custo_total, datetime.utcnow().isoformat()),
        commit=True,
    )
    flash(f"Cenário salvo com custo total estimado R$ {custo_total}", "success")
    return redirect(url_for("simulacoes.index"))
