from flask import Blueprint, flash, redirect, render_template, request, url_for

from ...services import cadastros
from ...services.security import login_required, role_required

bp = Blueprint("cadastros", __name__, url_prefix="/cadastros")


@bp.route("/pedidos", methods=["GET", "POST"])
@login_required
def pedidos():
    if request.method == "POST":
        try:
            cliente_id = int(request.form.get("cliente_id"))
            destino_lat = float(request.form.get("destino_lat"))
            destino_lon = float(request.form.get("destino_lon"))
            cidade = request.form.get("cidade") or "Sao Paulo"
            uf = request.form.get("uf") or "SP"
            janela_inicio = request.form.get("janela_inicio")
            janela_fim = request.form.get("janela_fim")
            sla_minutos = int(request.form.get("sla_minutos"))
        except (TypeError, ValueError):
            flash("Preencha os campos corretamente.", "danger")
        else:
            pedido_id = cadastros.create_pedido(
                cliente_id,
                destino_lat,
                destino_lon,
                cidade,
                uf,
                janela_inicio,
                janela_fim,
                sla_minutos,
            )
            flash(f"Pedido {pedido_id} criado.", "success")
            return redirect(url_for("cadastros.pedidos"))

    clientes = cadastros.list_clientes()
    pedidos = cadastros.list_pedidos()
    return render_template("pedidos.html", clientes=clientes, pedidos=pedidos)


@bp.route("/basico")
@login_required
@role_required("admin")
def basico():
    clientes = cadastros.list_clientes()
    veiculos = cadastros.list_veiculos()
    motoristas = cadastros.list_motoristas()
    return render_template(
        "cadastros.html", clientes=clientes, veiculos=veiculos, motoristas=motoristas
    )
